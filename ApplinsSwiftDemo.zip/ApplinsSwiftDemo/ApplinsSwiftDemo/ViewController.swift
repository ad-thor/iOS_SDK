//
//  ViewController.swift
//  ApplinsSwiftDemo
//
//  Created by root on 2023/3/31.
//

import UIKit
import ApplinsSDK

class ViewController: UIViewController, ALSAdViewDelegate, ALSRewardVideoDelegate,ALSNativeAdDelegate {

    @IBOutlet weak var BannerBtn: UIButton!
    @IBOutlet weak var InterstitialBtn: UIButton!
    @IBOutlet weak var RVBtn: UIButton!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        Applins.shareSDK().setSchemaHttps()
        Applins.shareSDK().uploadConsentValue("yes", consentType: "GDPR") { success in
        }
        Applins.shareSDK().setIsChildDirected(false)
        Applins.shareSDK().initSDK("31840716")
        BannerBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        InterstitialBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
        RVBtn.addTarget(self, action: #selector(clickEvent(_:)), for: .touchUpInside)
       
    }
    
    //携带参数
    @objc func clickEvent(_ sender: UIButton) {
        switch sender.titleLabel?.text{
        case "Load Banner":
            NSLog("%@", "Load Banner")
            Applins.shareSDK().getBannerAD("31840716", delegate: self, adSize: ALSBannerSizeW320H50, isTest: false)
        case "Load Interstitial":
            NSLog("%@", "Load Interstitial")
            Applins.shareSDK().preloadInterstitialAd("43853666", delegate: self, isTest: false)
        case "Load Rewarded Video":
            NSLog("%@", "Load Rewarded Video")
            Applins.shareSDK().preloadRewardedVideoAD("34159155", delegate: self)
        case .none:
            NSLog("%@", "none")
        case .some(_):
            NSLog("%@", "some")
        }
    }
    
    //banner delegate
    func alsLoadBannerSuccess(_ adView: ALSADMRAIDView!) {
        self.view.addSubview(adView)
        adView.frame = CGRectMake(25, 500, 320, 50)
    }
        
    //interstitial delegate
    func alsLoadInterstitialSuccess(withSlot slot: String!) {
        if Applins.shareSDK().isInterstitialReady(){
            Applins.shareSDK().showInterstitialAD()
        }
    }
    
    //banner and interstiail delegate
    func alsAdView(_ adView: ALSADMRAIDView!, loadADFailedWithError error: Error!) {
        NSLog("%@%@", "loadADFailedWithError: " , error.localizedDescription)
    }
    
    func alsAdViewShow(_ adView: ALSADMRAIDView!) {
        NSLog("%@%@", "impression ad slotid: " , adView.slot)
    }
    
    func alsAdViewClicked(_ adView: ALSADMRAIDView!) {
        NSLog("%@%@", "click ad slotid: " , adView.slot)
    }
    
    //rewarded video delegate
    func alsRewardedVideoLoadSuccess(){
        if Applins.shareSDK().isRewardedVideoReady(){
            Applins.shareSDK().showRewardedVideo()
        }
    }
    
    func alsRewardVideoLoadingFailed(_ error: Error!) {
        NSLog("%@", error.localizedDescription)
    }
    
    func alsRewardedVideoStart() {
        NSLog("%@", "alsRewardedVideoStart")
    }
    
    func alsRewardedVideoFinish() {
        NSLog("%@", "alsRewardedVideoFinish")
    }
    
    func alsRewardedVideoClicked() {
        NSLog("%@", "alsRewardedVideoClicked")
    }
    
    //reward user in the function
    func alsRewardedName(_ rewardName: String!, rewardedAmount: String!, customParams: String!) {
        NSLog("%@%@%@%@", "RewardedItmeName:", rewardName, " ,rewardedAmount:", rewardedAmount)
    }
    
    //native delegate
    func alsNativeAdImpression(_ nativeAd: UIView!) {
        
    }
    
    func alsNativeADClicked(_ nativeAd: UIView!) {
        
    }

}


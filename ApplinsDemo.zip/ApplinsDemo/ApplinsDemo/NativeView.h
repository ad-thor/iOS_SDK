

#import <ApplinsSDK/ApplinsSDK.h>
@interface NativeView : ALSNativeAd

- (void)adShow;
@end

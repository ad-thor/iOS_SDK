//
//  NativeVideoListViewController.m
//  ApplinsSDK_iOS
//
//  Created by 兰旭平 on 2018/8/30.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

//@import ApplinsSDK;
#import "NativeVideoListViewController.h"
#import <ApplinsSDK/Applins.h>
#import "NativeVideoTableViewCell.h"

static NSString *const kDefaultCellIdentifier = @"kDefaultCellIdentifier";
static NSString *const kCellIdentifier = @"kCellIdentifier";

@interface MediaTableViewCell : UITableViewCell
@property (nonatomic, strong)ALSMediaView *mediaView;
@property (nonatomic, strong)UILabel *nvTitleLable;
@end

@implementation MediaTableViewCell
- (void)awakeFromNib {
    [super awakeFromNib];
}
@end

@interface NativeVideoListViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (strong, nonatomic) NSMutableArray *_tableViewContentArray;
@property (nonatomic, assign) int insert;
@end

@implementation NativeVideoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addRefreshButton];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[MediaTableViewCell class] forCellReuseIdentifier:kCellIdentifier];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:kDefaultCellIdentifier];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.insert =  1 + arc4random() % (9);
    [self.tableView reloadData];
    [self loadAds];
}

- (void)addRefreshButton {
    UIButton *leftbutton=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 80, 20)];
    [leftbutton setTitle:@"刷新" forState:UIControlStateNormal];
    [leftbutton addTarget:self action:@selector(loadAds) forControlEvents:UIControlEventTouchUpInside];
    [leftbutton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    UIBarButtonItem *rightitem=[[UIBarButtonItem alloc]initWithCustomView:leftbutton];
    
    self.navigationItem.rightBarButtonItem=rightitem;
}

- (void)loadAds {
    [[Applins shareSDK] getNativeVideoAD:@"40744377" delegate:self imageRate:ALSImageWHRateOnePointNineToOne isTest:YES];//  
}
#pragma mark - ALS success delegate
-(void)ALSNativeVideoLoadSuccess:(ALSNativeVideoModel *)nativeVideoModel{
    [self._tableViewContentArray insertObject:nativeVideoModel atIndex:self.insert];
    [self.tableView reloadData];
    NSLog(@"%s",__func__);
}
-(void)ALSNativeVideoLoadFailed:(NSError *)error{
    NSString *errmsg = [[NSString alloc] initWithFormat:@"error no: %ld, err msg: %@", (long)error.code, error.domain];
    NSLog(@"%s",__func__);
    NSLog(@"%@",errmsg);
}
- (NSMutableArray *)tableViewContentArray {
    if (!__tableViewContentArray) {
        self._tableViewContentArray = [NSMutableArray array];
        for (NSUInteger i = 0; i < 10; i++) {
            [self._tableViewContentArray addObject:[NSString stringWithFormat:@"TableView Cell #%lu", (unsigned long)(i + 1)]];
        }
    }
    
    return self._tableViewContentArray;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    }
    return _tableView;
}
#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self.tableViewContentArray count];
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id obj = self._tableViewContentArray[indexPath.row];
    if ([obj isKindOfClass:[ALSNativeVideoModel class]]) {
        MediaTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier forIndexPath:indexPath];
        [cell.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        cell.nvTitleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 30)];//标题f
        cell.nvTitleLable.text = ((ALSNativeVideoModel *)obj).title;
        [cell addSubview:cell.nvTitleLable];
        cell.mediaView = [[ALSMediaView alloc] initWithFrame:CGRectMake(0, 30, self.view.frame.size.width, self.view.frame.size.width/1.77)];
        cell.mediaView.enableAutoPlay = YES;
        cell.mediaView.enableWWANPlay = NO;
        [cell.mediaView setNativeVideoAd:obj];
        [cell addSubview:cell.mediaView];
        return cell;
    } else {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kDefaultCellIdentifier forIndexPath:indexPath];
        cell.textLabel.text = (NSString *)obj;
        return cell;
    }
}
- (void)getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}
#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id obj = self._tableViewContentArray[indexPath.row];
    if ([obj isKindOfClass:[ALSNativeVideoModel class]]) {
        return [self getCellHeight];
    }
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    id obj = self._tableViewContentArray[indexPath.row];
    if ([obj isKindOfClass:[NSString class]]) {
        UIViewController *vc = [UIViewController new];
        vc.view.backgroundColor = [UIColor whiteColor];
        [self.navigationController pushViewController:vc animated:YES];
    } else {
        [((ALSNativeVideoModel *)obj) clickToPushOnParentVC:self animated:YES];
    }
}
- (CGFloat)getCellHeight{
    NSInteger titleHeight = 30;
    //视频比例1:1.77
    NSInteger movieViewHeight = self.view.frame.size.width / 1.77;
    return titleHeight + movieViewHeight ;
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //从其他ui切换回tableview时，需要处理可见cell播放视频
//    NSArray * array = [self.tableView indexPathsForVisibleRows];
//    NSLog(@"viewWillAppear ---%ld",array.count);

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSArray * array = [self.tableView indexPathsForVisibleRows];
    NSLog(@"scrollViewDidScroll可视cell个数 ---%ld",array.count);
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
//    NSArray * array = [self.tableView indexPathsForVisibleRows];
//    NSLog(@"viewWillDisappear ---%ld",array.count);
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
//    NSArray * array = [self.tableView indexPathsForVisibleRows];
//    NSLog(@"viewDidDisappear ---%ld",array.count);
}
@end

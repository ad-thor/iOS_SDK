

#import "NativeView.h"
@implementation NativeView

- (void)adShow {
    //backgroundView
    UIView *backgroundView = [[UIView alloc]initWithFrame:CGRectMake(10, 70+30,self.frame.size.width - 20, (self.frame.size.width - 20)/1.9 + 120)];
    [backgroundView setBackgroundColor:[UIColor colorWithRed:0xf7/255.0 green:0xe7/255.0 blue:0xd6/255.0 alpha:1]];
    [self addSubview:backgroundView];
    
    //imageView
    UIImageView *imageView = [[UIImageView alloc]initWithImage:self.adNativeModel.AdImage];
    imageView.frame =CGRectMake(15, 80+30,self.frame.size.width - 30, (self.frame.size.width - 30)/1.9);
    [self addSubview:imageView];
    
    
    //ADsignImage
    UIImageView *ADsignImage = [[UIImageView alloc]initWithImage:self.adNativeModel.ADsignImage];
    ADsignImage.frame =CGRectMake(15, 80+30,16, 16);
    [self addSubview:ADsignImage];
    
    
    //iconView
    UIImageView *iconView = [[UIImageView alloc]initWithImage:self.adNativeModel.iconImage];
       iconView.frame =CGRectMake(15, 95+ (self.frame.size.width - 30)/1.9 +30, 70, 70);
       [self addSubview:iconView];
    
    //title
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(90, 95+ (self.frame.size.width - 30)/1.9 +30, 200, 40)];
    titleLabel.userInteractionEnabled = YES;
    UIFont *font = [UIFont systemFontOfSize:22.0];
    titleLabel.font = font;
    titleLabel.textColor = [UIColor grayColor];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.text = self.adNativeModel.title;
    [self addSubview:titleLabel];
    
    //desc
    UILabel *descLabel = [[UILabel alloc] initWithFrame:CGRectMake(90, 95+ (self.frame.size.width - 30)/1.9+40+30, self.frame.size.width - 30-75, 30)];
    descLabel.userInteractionEnabled = YES;
    descLabel.textColor = [UIColor grayColor];
    descLabel.backgroundColor = [UIColor clearColor];
    descLabel.textAlignment = NSTextAlignmentLeft;
    descLabel.text = self.adNativeModel.desc;
    [self addSubview:descLabel];
    
    //button desc 此处不要用button,用Lable即可,否则拦截点击事件,SDK无法难道点击事件.
    
    UILabel *buttonLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, (self.frame.size.width - 20)/1.9 + 260 +30,self.frame.size.width - 20, 50)];
    buttonLabel.userInteractionEnabled = YES;
    buttonLabel.textColor = [UIColor whiteColor];
    buttonLabel.backgroundColor = [UIColor colorWithRed:0xe6/255.0 green:0x81/255.0 blue:0x1a/255.0 alpha:1];
    buttonLabel.textAlignment = NSTextAlignmentCenter;
    buttonLabel.text = self.adNativeModel.button;
    [self addSubview:buttonLabel];
    
    
    //close button
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.frame = CGRectMake(self.frame.size.width -60 , 40, 50, 30);
    [button setTitle:@"关闭" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor orangeColor];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor grayColor] forState:UIControlStateDisabled];
    button.titleLabel.font = [UIFont systemFontOfSize:19];
    [button addTarget:self action:@selector(closeAD) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:button];

}


- (void)closeAD {
    [self removeFromSuperview];
    UIViewController *top = [self topViewController];
    [top.navigationController setNavigationBarHidden:NO animated:NO];

}






//下面的代码无需关注
- (UIViewController *)topViewController {
    UIViewController *resultVC;
    resultVC = [self _topViewController:[[UIApplication sharedApplication].keyWindow rootViewController]];
    while (resultVC.presentedViewController) {
        resultVC = [self _topViewController:resultVC.presentedViewController];
    }
    return resultVC;
}

- (UIViewController *)_topViewController:(UIViewController *)vc {
    if ([vc isKindOfClass:[UINavigationController class]]) {
        return [self _topViewController:[(UINavigationController *)vc topViewController]];
    } else if ([vc isKindOfClass:[UITabBarController class]]) {
        return [self _topViewController:[(UITabBarController *)vc selectedViewController]];
    } else {
        return vc;
    }
    return nil;
}

@end

//
//  AdRequestView.m
//  ApplinsDemo
//
//  Created by 兰旭平 on 2018/12/26.
//  Copyright © 2018 兰旭平. All rights reserved.
//

#import "AdRequestView.h"
//@import ApplinsSDK;
#import "NativeVideoListViewController.h"
#import <ApplinsSDK/Applins.h>
#import "ALSView.h"
@interface AdRequestView ()<ALSNativeAdDelegate>
@property (nonatomic, assign)ALSBannerSize bannerSize;
@end

@implementation AdRequestView

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.titleText;
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)request:(id)sender {
    switch (self.tag) {
        case 0:
            [[Applins shareSDK] getBannerAD:@"99397457" delegate:self adSize:ALSBannerSizeW320H50 isTest:NO];
            break;
        case 1:
            [[Applins shareSDK] preloadInterstitialAd:@"53479848" delegate:self isTest:YES];
            break;
        case 2:
            [self loadNative];
            break;
        case 3:
            [self loadAppwall];
            break;
        case 4:
            [[Applins shareSDK] preloadRewardedVideoAD:@"30769964" delegate:self];
            break;
        case 5:
            [self.navigationController pushViewController:[NativeVideoListViewController new] animated:YES];
            break;
        default:
            break;
    }
}
- (void)loadAppwall {
    [[Applins shareSDK] preloadAppWall:@"57141680" customColor:nil delegate:self isTest:YES success:^{
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self presentViewController:[[Applins shareSDK] showAppWallViewController] animated:YES completion:nil];
        })
        ;
    } failure:^(NSError *error) {
        NSLog(@"%@",error);
    }];
}
- (void)loadNative {
    [[Applins shareSDK] getNativeAD:@"57141680" delegate:self imageRate:ALSImageWHRateOnePointNineToOne isTest:YES success:^(ALSNativeAdModel *nativeModel) {
        ALSView *ccview = [[ALSView alloc]initWithFrame:CGRectMake(30, 100, self.view.frame.size.width-60, (self.view.frame.size.width-60)/1.9+20)];
        ccview.delegate = self;
        [ccview setValuesWith:nativeModel];
        [self.view addSubview:ccview];
    } failure:^(NSError *error) {
    }];
}

#pragma mark - mraid banner
- (void)ALSLoadBannerSuccess:(ALSADMRAIDView*)adView {
    adView.frame = CGRectMake(0, 100, adView.frame.size.width, adView.frame.size.height);
    [self.view addSubview:adView];
    NSLog(@"%s",__func__);
}
- (void)ALSLoadInterstitialSuccessWithSlot:(NSString *)slot {
    if ([[Applins shareSDK] isInterstitialReady]){
        [[Applins shareSDK] showInterstitialAD];
    }
    NSLog(@"%s",__func__);
}
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error {
    NSLog(@"%@",error);
    NSLog(@"%s",__func__);
}
- (void)ALSAdViewClicked:(ALSADMRAIDView *)adView{
    NSLog(@"%s",__func__);
}
#pragma mark - Appwall Delegate
- (void)ALSAppWallDidClick:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallDidIntoLandingPage:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallDidLeaveLandingPage:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallWillLeaveApplication:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallClosed {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallJumpfail:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
#pragma mark - Native Delegate
- (void)ALSNativeADClicked:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeWillJumpToAppStore:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdDidLeaveLandingPage:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdWillLeaveApplication:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdJumpfailed:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
#pragma mark - RewardVideo Delegate

- (void)ALSRewardedVideoLoadSuccess{
    [[Applins shareSDK] showRewardedVideo];
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoStart {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoFinish {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoClicked {
    NSLog(@"%s",__func__);}
- (void)ALSRewardedVideoWillJumpToAppStore {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoJumpFailed {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardVideoLoadingFailed:(NSError *)error {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedName:(NSString *)rewardName rewardedAmount:(NSString *)rewardedAmount customParams:(NSString *)customParams{
    NSLog(@"%s",__func__);
}
- (void)ALSRewardVideoClosed {
    NSLog(@"%s",__func__);
}

@end

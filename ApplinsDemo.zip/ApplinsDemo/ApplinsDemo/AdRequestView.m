//
//  AdRequestView.m
//  ApplinsDemo
//
//  Created by 兰旭平 on 2018/12/26.
//  Copyright © 2018 兰旭平. All rights reserved.
//

#import "AdRequestView.h"
//@import ApplinsSDK;
#import "NativeVideoListViewController.h"
#import <ApplinsSDK/Applins.h>
#import "ALSView.h"
#import "NativeView.h"
@interface AdRequestView ()<ALSNativeAdDelegate>
@property (nonatomic, assign)ALSBannerSize bannerSize;
@property (nonatomic, strong)UIButton *btn;

@end

@implementation AdRequestView

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.titleText;
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)request:(id)sender {
    self.btn = (UIButton *)sender;

    switch (self.tag) {
        case 0:
            [[Applins shareSDK] getBannerAD:@"31840716" delegate:self adSize:ALSBannerSizeW320H50 isTest:NO];
            break;
        case 1:
            [[Applins shareSDK] preloadInterstitialAd:@"43853666" delegate:self isTest:YES];//53479848
            break;
        case 2:
            [self loadNative];
            break;
        case 3:
            [self loadAppwall];
            break;
        case 4:
            [[Applins shareSDK] preloadRewardedVideoAD:@"34159155" delegate:self];//  30769964
            break;
        case 5:
            [self.navigationController pushViewController:[NativeVideoListViewController new] animated:YES];
            break;
        case 6:
            self.btn.enabled = NO;
            [self loadNativeMakeInterstitial];
            break;
        default:
            break;
    }
}
- (void)loadAppwall {
//    [[Applins shareSDK] preloadAppWall:@"57141680" customColor:nil delegate:self isTest:YES success:^{
//        dispatch_sync(dispatch_get_main_queue(), ^{
//            [self presentViewController:[[Applins shareSDK] showAppWallViewController] animated:YES completion:nil];
//        })
//        ;
//    } failure:^(NSError *error) {
//        NSLog(@"%@",error);
//    }];
}
- (void)loadNative {
    [[Applins shareSDK] getNativeAD:@"81427091" delegate:self imageRate:ALSImageWHRateOnePointNineToOne isTest:YES success:^(ALSNativeAdModel *nativeModel) {
        ALSView *ccview = [[ALSView alloc]initWithFrame:CGRectMake(30, 100, self.view.frame.size.width-60, (self.view.frame.size.width-60)/1.9+20)];
        ccview.delegate = self;
        [ccview setValuesWith:nativeModel];
        [self.view addSubview:ccview];
    } failure:^(NSError *error) {
    }];
}
- (void)loadNativeMakeInterstitial {
    [[Applins shareSDK] preloadNativeAD:@"81427091" delegate:self imageRate:ALSImageWHRateOnePointNineToOne preloadImage:YES isTest:NO success:^(ALSNativeAdModel *nativeModel) {
           self.btn.enabled = YES;
           [self.navigationController setNavigationBarHidden:YES animated:NO];
           //设置广告页面
           NativeView *adView = [[NativeView alloc] init];
           adView.frame = self.view.frame;
           adView.delegate = self;
           adView.adNativeModel = nativeModel; // 这一步必须有不然没有点击
           [adView setBackgroundColor:[UIColor colorWithRed:0xec/255.0 green:0xc7/255.0 blue:0xa3/255.0 alpha:1]];
           [adView adShow];
           [self.view addSubview:adView];
           
       } failure:^(NSError *error) {
           self.btn.enabled = YES;
           
       }];
}
#pragma mark - mraid banner
- (void)ALSLoadBannerSuccess:(ALSADMRAIDView*)adView {
    adView.frame = CGRectMake(0, 100, adView.frame.size.width, adView.frame.size.height);
    [self.view addSubview:adView];
    NSLog(@"%s",__func__);
}
- (void)ALSLoadInterstitialSuccessWithSlot:(NSString *)slot {
    if ([[Applins shareSDK] isInterstitialReady]){
        [[Applins shareSDK] showInterstitialAD];
    }
    NSLog(@"%s",__func__);
}
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error {
    NSLog(@"%@",error);
    NSLog(@"%s",__func__);
}
- (void)ALSAdViewClicked:(ALSADMRAIDView *)adView{
    NSLog(@"%s",__func__);
}
#pragma mark - Appwall Delegate
- (void)ALSAppWallDidClick:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallDidIntoLandingPage:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallDidLeaveLandingPage:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallWillLeaveApplication:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallClosed {
    NSLog(@"%s",__func__);
}
- (void)ALSAppWallJumpfail:(ALSNativeAd *)nativeAd {
    NSLog(@"%s",__func__);
}
#pragma mark - Native Delegate
- (void)ALSNativeADClicked:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeWillJumpToAppStore:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdDidLeaveLandingPage:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdWillLeaveApplication:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdJumpfailed:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
#pragma mark - RewardVideo Delegate

- (void)ALSRewardedVideoLoadSuccess{
    [[Applins shareSDK] showRewardedVideo];
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoStart {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoFinish {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoClicked {
    NSLog(@"%s",__func__);}
- (void)ALSRewardedVideoWillJumpToAppStore {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedVideoJumpFailed {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardVideoLoadingFailed:(NSError *)error {
    NSLog(@"%s",__func__);
}
- (void)ALSRewardedName:(NSString *)rewardName rewardedAmount:(NSString *)rewardedAmount customParams:(NSString *)customParams{
    NSLog(@"%s",__func__);
}
- (void)ALSRewardVideoClosed {
    NSLog(@"%s",__func__);
}
@end

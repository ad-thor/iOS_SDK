//
//  ViewController.m
//  ApplinsDemo
//
//  Created by 兰旭平 on 2018/12/26.
//  Copyright © 2018 兰旭平. All rights reserved.
//

#import "ViewController.h"
#import "AdRequestView.h"
#import <ApplinsSDK/Applins.h>
#import "ALSView.h"
#import <ApplinsSDK/ALSADExternalDelegate.h>
@interface ViewController()<ALSNativeAdDelegate>
@property(nonatomic, strong) UILabel *label;
@property(nonatomic, strong) UIButton *button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =  [UIColor orangeColor];
    
    self.label = [[UILabel alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2-150, 320, 300, 40)];
    self.label.userInteractionEnabled = YES;
    self.label.textColor = [UIColor redColor];
    self.label.backgroundColor = [UIColor orangeColor];
    self.label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.label];
    
    self.button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.button.frame = CGRectMake(self.view.frame.size.width/2-100, 400, 200, 40);
    [self.button setTitle:@"获取广告" forState:UIControlStateNormal];
    self.button.backgroundColor = [UIColor blueColor];
    [self.button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.button setTitleColor:[UIColor grayColor] forState:UIControlStateDisabled];
    self.button.titleLabel.font = [UIFont systemFontOfSize:25];
    [self.button addTarget:self action:@selector(getNativeAd:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.button];

}

- (void)getNativeAd:(UIButton *)btn {
    self.button.enabled = NO;
    self.label.text = @"正在获取广告...";
    
    [[Applins shareSDK] preloadNativeAD:@"81427091" delegate:self imageRate:ALSImageWHRateOnePointNineToOne preloadImage:YES isTest:NO success:^(ALSNativeAdModel *nativeModel) {
        self.label.text = @"";
        self.button.enabled = YES;
        
        //设置广告页面
        ALSView *adView = [[ALSView alloc] init];
        adView.frame = self.view.frame;
        adView.delegate = self;
        adView.adNativeModel = nativeModel; // 这一步必须有不然没有点击
        [adView setBackgroundColor:[UIColor colorWithRed:0xec/255.0 green:0xc7/255.0 blue:0xa3/255.0 alpha:1]];
        [adView adShow];
        [self.view addSubview:adView];
        
    } failure:^(NSError *error) {
        self.button.enabled = YES;
        self.label.text = @"获取广告失败!";
    }];
}

#pragma mark - Native Delegate
- (void)ALSNativeADClicked:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeWillJumpToAppStore:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdDidLeaveLandingPage:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdWillLeaveApplication:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
- (void)ALSNativeAdJumpfailed:(UIView *)nativeAd {
    NSLog(@"%s",__func__);
}
@end



#import <ApplinsSDK/ApplinsSDK.h>
@interface ALSView : ALSNativeAd

- (void)adShow;
@end

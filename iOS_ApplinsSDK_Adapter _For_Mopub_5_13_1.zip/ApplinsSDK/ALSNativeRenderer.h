//
//  ALSNativeRenderer.h
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/13.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import <Foundation/Foundation.h>
#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#elif __has_include(<MoPubSDKFramework/MoPub.h>)
    #import <MoPubSDKFramework/MoPub.h>
#else
    #import "MPNativeAdRenderer.h"
#endif

@class MPNativeAdRendererConfiguration;
@class MPStaticNativeAdRendererSettings;

@interface ALSNativeRenderer : NSObject<MPNativeAdRenderer>

/// The viewSizeHandler is used to allow the app to configure its native ad view size.
@property (nonatomic, readonly) MPNativeViewSizeHandler viewSizeHandler;

/// Constructs and returns an MPNativeAdRendererConfiguration object specific for the
/// ALSNativeRenderer. You must set all the properties on the configuration object.
/// @param rendererSettings Application defined settings.
/// @return A configuration object for ALSNativeRenderer.
+ (MPNativeAdRendererConfiguration *)rendererConfigurationWithRendererSettings:
(id<MPNativeAdRendererSettings>)rendererSettings;
@end

//
//  ALSRewardedVideoCustomEvent.m
//  AppstoreCtl
//
//  Created by Mirinda on 2017/11/15.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#if __has_include(<MoPub / MoPub.h>)
#import <MoPub/MoPub.h>
#else
#import "MPRewardedVideoReward.h"
#endif

#import "ALSRewardedVideoCustomEvent.h"
#import <ApplinsSDK/ApplinsSDK.h>


@interface ALSRewardedVideoCustomEvent()<ALSRewardVideoDelegate>
@property(nonatomic,assign)BOOL canPlay;
@property(nonatomic,strong)NSString *slot_id;

@end

@implementation ALSRewardedVideoCustomEvent

- (BOOL)isRewardExpected
{
    return YES;
}


- (BOOL)enableAutomaticImpressionAndClickTracking
{
    return NO;
}

- (void)requestAdWithAdapterInfo:(NSDictionary *)info adMarkup:(NSString *)adMarkup {
    NSString *slotid = [info objectForKey:@"slotid"];
    self.slot_id = slotid;
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK initSDK:slotid];
    
    [alsSDK preloadRewardedVideoAD:slotid delegate:self];
    
}


- (void)presentAdFromViewController:(UIViewController *)viewController
{
    [[Applins shareSDK] showRewardedVideo];
}

- (BOOL)hasAdAvailable
{
    return self.canPlay;
}

- (void)ALSRewardedVideoLoadSuccess
{
    self.canPlay = [[Applins shareSDK] isRewardedVideoReady];
    
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidTrackImpression:)]) {
        [self.delegate fullscreenAdAdapterDidTrackImpression:self];
    }
    
    MPLogAdEvent([MPLogEvent adLoadSuccessForAdapter:NSStringFromClass(self.class)], self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidLoadAd:)]) {
        [self.delegate fullscreenAdAdapterDidLoadAd:self];
    }
}



/**
 *  ALSRewardVideo Click Ads
 **/
- (void)ALSRewardedVideoClicked {
    MPLogAdEvent([MPLogEvent adTappedForAdapter:NSStringFromClass(self.class)], self.slot_id);
    
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidReceiveTap:)]) {
        [self.delegate fullscreenAdAdapterDidReceiveTap:self];
    }
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidTrackClick:)]) {
        [self.delegate fullscreenAdAdapterDidTrackClick:self];
    }
    
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterWillLeaveApplication:)]) {
        [self.delegate fullscreenAdAdapterWillLeaveApplication:self];
    }
}


/**
 *  reward
 **/
- (void)ALSRewardedName:(NSString *)rewardName rewardedAmount:(NSString *)rewardedAmount customParams:(NSString*) customParams
{
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapter: willRewardUser:)])
    {
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        numberFormatter.numberStyle = kCFNumberFormatterNoStyle;
        NSNumber *num = [numberFormatter numberFromString:rewardedAmount];
        MPRewardedVideoReward *rw = [[MPRewardedVideoReward alloc]initWithCurrencyType:rewardName amount:num];
        [self.delegate fullscreenAdAdapter:self willRewardUser:rw];
    }
}


/**
 *  ALSRewardVideo loading failed
 **/
- (void)ALSRewardVideoLoadingFailed:(NSError *)error {
    
    MPLogAdEvent([MPLogEvent adLoadFailedForAdapter:NSStringFromClass(self.class) error:error], nil);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapter:didFailToLoadAdWithError:)]) {
        [self.delegate fullscreenAdAdapter:self didFailToLoadAdWithError:error];
    }
}

- (void)ALSRewardVideoClosed
{
    MPLogAdEvent([MPLogEvent adWillDisappearForAdapter:NSStringFromClass(self.class)], self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterAdWillDisappear:)]) {
        [self.delegate fullscreenAdAdapterAdWillDisappear:self];
    }
    
    MPLogAdEvent([MPLogEvent adDidDisappearForAdapter:NSStringFromClass(self.class)], self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterAdDidDisappear:)]) {
        [self.delegate fullscreenAdAdapterAdDidDisappear:self];
    }
}

- (void)showAd
{
    MPLogAdEvent([MPLogEvent adWillAppearForAdapter:NSStringFromClass(self.class)], self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterAdWillAppear:)]) {
        [self.delegate fullscreenAdAdapterAdWillAppear:self];
    }
    
    MPLogAdEvent([MPLogEvent adDidAppearForAdapter:NSStringFromClass(self.class)], self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterAdDidAppear:)]) {
        [self.delegate fullscreenAdAdapterAdDidAppear:self];
    }
}

@end

//
//  ALSBannerCustomEvent.h
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/7.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#if __has_include(<MoPub/MoPub.h>)
#import <MoPub/MoPub.h>
#elif __has_include(<MoPubSDKFramework/MoPub.h>)
#import <MoPubSDKFramework/MoPub.h>
#else
#import "MPInlineAdAdapter.h"
#endif

#import <ApplinsSDK/ALSADExternalDelegate.h>

@interface ALSBannerCustomEvent : MPInlineAdAdapter <MPThirdPartyInlineAdAdapter>

@end

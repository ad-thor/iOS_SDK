//
//  ALSBannerCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/7.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "ALSBannerCustomEvent.h"
#import <ApplinsSDK/ApplinsSDK.h>
#import <ApplinsSDK/ALSADMRAIDView.h>

@interface ALSBannerCustomEvent()<ALSAdViewDelegate>
@property (nonatomic,strong)ALSADMRAIDView* mraidBanner;
@property(nonatomic, strong) NSString *slot_id;

@end

@implementation ALSBannerCustomEvent


- (BOOL)enableAutomaticImpressionAndClickTracking
{
    return NO;
}

- (void)requestAdWithSize:(CGSize)size adapterInfo:(NSDictionary *)info adMarkup:(NSString *)adMarkup{
    [self requestAdWithSize:size customEventInfo:info];
}

- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    self.slot_id = slotid;
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK initSDK:slotid];
    
    ALSBannerSize bannerSize;
    if (size.height > 25 && size.height <= 75)
    {
        bannerSize = ALSBannerSizeW320H50;
    }
    else if (size.height > 75 && size.height <= 175)
    {
        bannerSize = ALSBannerSizeW320H100;
    }
    else if (size.height > 175 && size.height < 300)
    {
        bannerSize = ALSBannerSizeW300H250;
    }
    else
    {
        NSError* error = [NSError errorWithDomain:@"No ad for input banner size." code:99999 userInfo:nil];
        if ([self.delegate respondsToSelector:@selector(inlineAdAdapter:didFailToLoadAdWithError:)])
        {
            [self.delegate inlineAdAdapter:self didFailToLoadAdWithError:error];
        }
        return;
    }

    [alsSDK getBannerAD:slotid delegate:self adSize:bannerSize isTest:YES]; 
}

- (void)dealloc
{
    if (self.mraidBanner)
    {
        [self.mraidBanner removeFromSuperview];
    }
}

#pragma mark ALSAdViewDelegate methods

//banner ad
- (void)ALSLoadBannerSuccess:(ALSADMRAIDView*)adView {
    self.mraidBanner = adView;
    
    MPLogAdEvent([MPLogEvent adLoadSuccessForAdapter:NSStringFromClass(self.class)], self.slot_id);
    MPLogAdEvent([MPLogEvent adShowAttemptForAdapter:NSStringFromClass(self.class)], self.slot_id);
    MPLogAdEvent([MPLogEvent adShowSuccessForAdapter:NSStringFromClass(self.class)], self.slot_id);
    
    if ([self.delegate respondsToSelector:@selector(inlineAdAdapter:didLoadAdWithAdView:)])
    {
        [self.delegate inlineAdAdapter:self didLoadAdWithAdView:adView];
    }

    if ([self.delegate respondsToSelector:@selector(inlineAdAdapterDidTrackImpression:)])
    {
        [self.delegate inlineAdAdapterDidTrackImpression:self];
    }
    
}

//error while request ads.
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error {
    MPLogAdEvent([MPLogEvent adLoadFailedForAdapter:NSStringFromClass(self.class) error:error], nil);
    
    if ([self.delegate respondsToSelector:@selector(inlineAdAdapter:didFailToLoadAdWithError:)])
    {
        [self.delegate inlineAdAdapter:self didFailToLoadAdWithError:error];
    }
}

//jump to safari or internal webview
- (BOOL)ALSAdView:(ALSADMRAIDView*)adView shouldOpenURL:(NSURL*)url {
    MPLogAdEvent([MPLogEvent adTappedForAdapter:NSStringFromClass(self.class)], self.slot_id);

    if ([self.delegate respondsToSelector:@selector(inlineAdAdapterDidTrackClick:)])
    {
        [self.delegate inlineAdAdapterDidTrackClick:self];
    }
    return YES;
}

//will leave application
- (void)ALSAdViewWillLeaveApplication:(ALSADMRAIDView*)adView {
    MPLogAdEvent([MPLogEvent adWillLeaveApplicationForAdapter:NSStringFromClass(self.class)],
    self.slot_id);
    if ([self.delegate respondsToSelector:@selector(inlineAdAdapterWillLeaveApplication:)])
    {
        [self.delegate inlineAdAdapterWillLeaveApplication:self];
    }
}

@end

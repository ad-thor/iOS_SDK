//
//  MPALSNativeAdAdapter.m
//  GoldMedal
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "ALSNativeAdAdapter.h"
#import "MPNativeAdConstants.h"

static NSString *const kALSIconKey = @"icon";
static NSString *const kALSImageKey = @"image";
static NSString *const kALSSignImageKey = @"ADsignImage";
static NSString *const kALSChoicesLinkKey = @"choices_link_url";

@implementation ALSNativeAdAdapter

@synthesize properties = _properties;
@synthesize defaultActionURL = _defaultActionURL;

- (instancetype)initWithALSNativeAd:(ALSNativeAdModel*)ALSNativeAd
{
    if ([super init])
    {
        self.nativeAd = ALSNativeAd;
        NSMutableDictionary *properties = [NSMutableDictionary dictionary];
        
        if (ALSNativeAd.title)
        {
            properties[kAdTitleKey] = ALSNativeAd.title;
        }
        
        if (ALSNativeAd.desc)
        {
            properties[kAdTextKey] = ALSNativeAd.desc;
        }
        
        if (ALSNativeAd.icon)
        {
            properties[kAdIconImageKey] = ALSNativeAd.icon;
        }
        
        if (ALSNativeAd.image)
        {
            properties[kAdMainImageKey] = ALSNativeAd.image;
        }
        
        if (ALSNativeAd.iconImage)
        {
            properties[kALSIconKey] = ALSNativeAd.iconImage;
        }
        
        if (ALSNativeAd.AdImage)
        {
            properties[kALSImageKey] = ALSNativeAd.AdImage;
        }
        
        if (ALSNativeAd.button)
        {
            properties[kAdCTATextKey] = ALSNativeAd.button;
        }
        
        if (ALSNativeAd.star)
        {
            properties[kAdStarRatingKey] = [NSString stringWithFormat:@"%f", ALSNativeAd.star];
        }
        
        if (ALSNativeAd.ADsignImage)
        {
            properties[kALSSignImageKey] = ALSNativeAd.ADsignImage;
        }
        
        if (ALSNativeAd.choices_link_url)
        {
            properties[kALSChoicesLinkKey] = ALSNativeAd.choices_link_url;
        }
        
        _properties = properties;

    }

    return self;
}


#pragma mark -delegate


#pragma mark - <MPNativeAdAdapter>

//- (UIView *)privacyInformationIconView
//{
    //return _adChoicesView;
//    return nil;
//}

- (BOOL)enableThirdPartyClickTracking
{
    return YES;
}

- (NSURL *)defaultActionURL
{
    return nil;
}

@end

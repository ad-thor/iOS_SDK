//
//  ALSInterstitialCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "ALSInterstitialCustomEvent.h"
#import <ApplinsSDK/ApplinsSDK.h>
#import <ApplinsSDK/ALSADMRAIDView.h>

@interface ALSInterstitialCustomEvent()<ALSAdViewDelegate>
@property(nonatomic, strong) NSString *slot_id;

@end

@implementation ALSInterstitialCustomEvent



- (void)requestAdWithAdapterInfo:(NSDictionary *)info adMarkup:(NSString *)adMarkup{
    [self requestInterstitialWithCustomEventInfo:info];
}

- (void)requestInterstitialWithCustomEventInfo:(NSDictionary *)info{
    NSString *slotid = [info objectForKey:@"slotid"];
    self.slot_id = slotid;
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK initSDK:slotid];
    [alsSDK preloadInterstitialAd:slotid delegate:self isTest:NO];
}


- (void)presentAdFromViewController:(UIViewController *)rootViewController{
    Applins *alsSDK = [Applins shareSDK];
    if([alsSDK isInterstitialReady]){
        [alsSDK showInterstitialAD];
        
        if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidTrackImpression:)]){
            [self.delegate fullscreenAdAdapterDidTrackImpression:self];
        }
    }
}

- (void)dealloc{
    
}

- (BOOL)isRewardExpected {
    return NO;
}

- (BOOL)hasAdAvailable {
    return [[Applins shareSDK]isInterstitialReady];
}

- (BOOL)enableAutomaticImpressionAndClickTracking{
    return NO;
}


#pragma mark CTAdViewDelegate methods
// Interstitial ad Success
- (void)ALSLoadInterstitialSuccess{
    MPLogAdEvent([MPLogEvent adLoadSuccessForAdapter:NSStringFromClass(self.class)],
                 self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidLoadAd:)]){
        [self.delegate fullscreenAdAdapterDidLoadAd:self];
    }
    
}

//error while request ads.
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error{
    MPLogAdEvent([MPLogEvent adLoadFailedForAdapter:NSStringFromClass(self.class) error:error],
                 self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapter:didFailToLoadAdWithError:)])
    {
        [self.delegate fullscreenAdAdapter:self didFailToLoadAdWithError:error];
    }
}

//jump to safari or internal webview
- (BOOL)ALSAdView:(ALSADMRAIDView*)adView shouldOpenURL:(NSURL*)url{
    MPLogAdEvent([MPLogEvent adTappedForAdapter:NSStringFromClass(self.class)], self.slot_id);

    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidTrackClick:)]){
        [self.delegate fullscreenAdAdapterDidTrackClick:self];
    }
    
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterDidReceiveTap:)]){
        [self.delegate fullscreenAdAdapterDidReceiveTap:self];
    }
    return YES;
}


//will leave application
- (void)ALSAdViewWillLeaveApplication:(ALSADMRAIDView*)adView{
    
    MPLogAdEvent([MPLogEvent adWillLeaveApplicationForAdapter:NSStringFromClass(self.class)],
                 self.slot_id );
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterWillLeaveApplication:)]){
        [self.delegate fullscreenAdAdapterWillLeaveApplication:self];
    }
}

//did click close button
- (void)ALSAdViewCloseButtonPressed:(ALSADMRAIDView*)adView {
    MPLogAdEvent([MPLogEvent adWillDisappearForAdapter:NSStringFromClass(self.class)],
                 self.slot_id);
    
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterAdWillDisappear:)]){
        [self.delegate fullscreenAdAdapterAdWillDisappear:self];
    }
    
    MPLogAdEvent([MPLogEvent adDidDisappearForAdapter:NSStringFromClass(self.class)],
                 self.slot_id);
    if ([self.delegate respondsToSelector:@selector(fullscreenAdAdapterAdDidDisappear:)]){
        [self.delegate fullscreenAdAdapterAdDidDisappear:self];
    }
}


@end

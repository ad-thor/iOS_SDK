//
//  GADMBannerApplins.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/15.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMBannerApplins.h"
#import <ApplinsSDK/ApplinsSDK.h>
@implementation GADMBannerApplins
@synthesize delegate;

- (void)requestBannerAd:(GADAdSize)adSize parameter:(NSString * _Nullable)serverParameter label:(NSString * _Nullable)serverLabel request:(nonnull GADCustomEventRequest *)request {
    ALSBannerSize ctSize;
    if (adSize.size.height == 100) {
        ctSize = ALSBannerSizeW320H100;
    } else if (adSize.size.height == 250) {
        ctSize = ALSBannerSizeW300H250;
    } else {
        ctSize = ALSBannerSizeW320H50;
    }
    [[Applins shareSDK] initSDK:serverParameter];
    [[Applins shareSDK] getBannerAD:serverParameter delegate:self adSize:ctSize isTest:NO];
}
//banner ad
- (void)ALSLoadBannerSuccess:(ALSADMRAIDView*)adView {
    [self.delegate customEventBanner:self didReceiveAd:adView];
}
//error while request ads.
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error {
    [self.delegate customEventBanner:self didFailAd:error];
}
//banner ad clicked
- (void)ALSAdViewClicked:(ALSADMRAIDView*)adView{
    [self.delegate customEventBannerWasClicked:self];
}

//jump to safari or internal webview
- (BOOL)ALSAdView:(ALSADMRAIDView*)adView shouldOpenURL:(NSURL*)url {
    [self.delegate customEventBannerWillPresentModal:self];
    [self.delegate customEventBannerDidDismissModal:self];
    return YES;
}
//will leave application
- (void)ALSAdViewWillLeaveApplication:(ALSADMRAIDView*)adView {
    [self.delegate customEventBannerWillLeaveApplication:self];
}
@end


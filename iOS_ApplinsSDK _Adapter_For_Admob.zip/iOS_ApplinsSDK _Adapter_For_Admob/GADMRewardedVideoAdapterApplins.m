//
//  GADMRewardedVideoAdapterApplins.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/10.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMRewardedVideoAdapterApplins.h"
#import <ApplinsSDK/ApplinsSDK.h>
@import GoogleMobileAds;

@interface GADMRewardedVideoAdapterApplins () <GADMRewardBasedVideoAdNetworkAdapter,ALSRewardVideoDelegate>
{
    __weak id<GADMRewardBasedVideoAdNetworkConnector> _rewardBasedVideoAdConnector;
}
@property NSString *slotID;
@end

@implementation GADMRewardedVideoAdapterApplins

+ (NSString *)adapterVersion
{
    return [[Applins shareSDK] getSDKVersion];
}

- (instancetype)initWithRewardBasedVideoAdNetworkConnector:(id<GADMRewardBasedVideoAdNetworkConnector>)connector {
    if (!connector) {
        return nil;
    }
    
    self = [super init];
    if (self) {
        _rewardBasedVideoAdConnector = connector;
        NSDictionary *credentials = [connector credentials];
        self.slotID = credentials[@"parameter"];
        [[Applins shareSDK] initSDK:self.slotID];
    }
    return self;
}
- (void)setUp
{
    if (self.slotID) {
        [[Applins shareSDK] initSDK:self.slotID];
        [_rewardBasedVideoAdConnector adapterDidSetUpRewardBasedVideoAd:self];
    } else {
        NSError *error = [NSError errorWithDomain:kGADErrorDomain
                                             code:kGADErrorMediationAdapterError
                                         userInfo:@{NSLocalizedDescriptionKey:
                                                        @"Adapter not initialized,Because CT SLOTID is nil!"}];
        [_rewardBasedVideoAdConnector adapter:self didFailToSetUpRewardBasedVideoAdWithError:error];
    }
}

- (void)requestRewardBasedVideoAd
{
    [[Applins shareSDK] preloadRewardedVideoAD:self.slotID delegate:self];
}

- (void)presentRewardBasedVideoAdWithRootViewController:(UIViewController *)viewController
{
    [[Applins shareSDK]  showRewardedVideoWithCustomViewController:viewController];
}

+ (Class<GADAdNetworkExtras>)networkExtrasClass {
    return nil;
}

- (void)stopBeingDelegate {
    
}

#pragma mark - ApplinsSDK DELEGATE

- (void)ALSRewardedVideoLoadSuccess
{
    [_rewardBasedVideoAdConnector adapterDidReceiveRewardBasedVideoAd:self];
}

- (void)ALSRewardedVideoStart
{
    [_rewardBasedVideoAdConnector adapterDidStartPlayingRewardBasedVideoAd:self];
    [_rewardBasedVideoAdConnector adapterDidOpenRewardBasedVideoAd:self];
}

- (void)ALSRewardedVideoFinish
{
    
}

- (void)ALSRewardedVideoClicked
{
    [_rewardBasedVideoAdConnector adapterDidGetAdClick:self];
}

- (void)ALSRewardedVideoWillJumpToAppStore
{
    [_rewardBasedVideoAdConnector adapterWillLeaveApplication:self];
}

- (void)ALSRewardedVideoJumpFailed
{
}

- (void)ALSRewardVideoLoadingFailed:(NSError *)error
{
    [_rewardBasedVideoAdConnector adapter:self didFailToLoadRewardBasedVideoAdwithError:error];
}

- (void)ALSRewardVideoClosed
{
    [_rewardBasedVideoAdConnector adapterDidCloseRewardBasedVideoAd:self];
}

- (void)ALSRewardedName:(NSString *)rewardName rewardedAmount:(NSString *)rewardedAmount customParams:(NSString*) customParams
{
    GADAdReward *reward = [[GADAdReward alloc] initWithRewardType:rewardName
                                                     rewardAmount:[NSDecimalNumber decimalNumberWithString:rewardedAmount]];
    [_rewardBasedVideoAdConnector adapter:self didRewardUserWithReward:reward];
}

@end

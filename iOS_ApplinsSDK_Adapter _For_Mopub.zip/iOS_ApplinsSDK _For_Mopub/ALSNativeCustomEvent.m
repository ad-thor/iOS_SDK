//
//  ALSNativeCustomEvent.m
//  GoldMedal
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "ALSNativeCustomEvent.h"
#import "ALSNativeAdAdapter.h"
#import <ApplinsSDK/ApplinsSDK.h>
#import "MPNativeAd.h"
#import "MPLogging.h"

@implementation ALSNativeCustomEvent

- (void)requestAdWithCustomEventInfo:(NSDictionary *)info adMarkup:(NSString *)adMarkup{
    [self requestAdWithCustomEventInfo:info];
}

- (void)requestAdWithCustomEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK initSDK:slotid];

    [alsSDK getNativeAD:slotid delegate:self imageRate:ALSImageWHRateOnePointNineToOne isTest:NO success:^(ALSNativeAdModel *nativeModel)
     {
         ALSNativeAdAdapter *adAdapter = [[ALSNativeAdAdapter alloc] initWithALSNativeAd:nativeModel];
         MPNativeAd *interfaceAd = [[MPNativeAd alloc] initWithAdAdapter:adAdapter];
         
         [self.delegate nativeCustomEvent:self didLoadAd:interfaceAd];
        
    } failure:^(NSError *error) {
        [self.delegate nativeCustomEvent:self didFailToLoadAdWithError:error];
    }];
}
@end

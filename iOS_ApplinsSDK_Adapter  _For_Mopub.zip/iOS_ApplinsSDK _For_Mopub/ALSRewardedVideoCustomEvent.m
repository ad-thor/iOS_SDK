//
//  ALSRewardedVideoCustomEvent.m
//  AppstoreCtl
//
//  Created by Mirinda on 2017/11/15.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#if __has_include(<MoPub / MoPub.h>)
#import <MoPub/MoPub.h>
#else
#import "MPRewardedVideoReward.h"
#endif

#import "ALSRewardedVideoCustomEvent.h"
#import <ApplinsSDK/ApplinsSDK.h>


@interface ALSRewardedVideoCustomEvent()<ALSRewardVideoDelegate>
@property(nonatomic,assign)BOOL canPlay;
@end

@implementation ALSRewardedVideoCustomEvent


- (void)requestRewardedVideoWithCustomEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK initSDK:slotid];
    
    [alsSDK preloadRewardedVideoAD:slotid delegate:self];
    
}


- (void)presentRewardedVideoFromViewController:(UIViewController *)viewController
{
    [[Applins shareSDK] showRewardedVideo];
}

- (BOOL)hasAdAvailable
{
    return self.canPlay;
}

- (void)ALSRewardedVideoLoadSuccess
{
    self.canPlay = [[Applins shareSDK] isRewardedVideoReady];
    if ([self.delegate respondsToSelector:@selector(trackImpression)]) {
        [self.delegate trackImpression];
    }
    if ([self.delegate respondsToSelector:@selector(rewardedVideoDidLoadAdForCustomEvent:)]) {
        [self.delegate rewardedVideoDidLoadAdForCustomEvent:self];
    }
}



/**
 *  ALSRewardVideo Click Ads
 **/
- (void)ALSRewardedVideoClicked
{
    if ([self.delegate respondsToSelector:@selector(trackClick)]) {
        [self.delegate trackClick];
    }
}


/**
 *  reward
 **/
- (void)ALSRewardedName:(NSString *)rewardName rewardedAmount:(NSString *)rewardedAmount customParams:(NSString*) customParams
{
    if ([self.delegate respondsToSelector:@selector(rewardedVideoShouldRewardUserForCustomEvent: reward:)])
    {
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        numberFormatter.numberStyle = kCFNumberFormatterNoStyle;
        NSNumber *num = [numberFormatter numberFromString:rewardedAmount];
        MPRewardedVideoReward *rw = [[MPRewardedVideoReward alloc]initWithCurrencyType:rewardName amount:num];
        [self.delegate rewardedVideoShouldRewardUserForCustomEvent:self reward:rw];
    }
}


/**
 *  ALSRewardVideo loading failed
 **/
- (void)ALSRewardVideoLoadingFailed:(NSError *)error
{
    if ([self.delegate respondsToSelector:@selector(rewardedVideoDidFailToPlayForCustomEvent:error:)]) {
        [self.delegate rewardedVideoDidFailToPlayForCustomEvent:self error:error];
    }
}

- (void)ALSRewardVideoClosed
{
    if ([self.delegate respondsToSelector:@selector(rewardedVideoWillDisappearForCustomEvent:)]) {
        [self.delegate rewardedVideoWillDisappearForCustomEvent:self];
    }
    
    if ([self.delegate respondsToSelector:@selector(rewardedVideoDidDisappearForCustomEvent:)]) {
        [self.delegate rewardedVideoDidDisappearForCustomEvent:self];
    }
}

- (void)showAd
{
    if ([self.delegate respondsToSelector:@selector(rewardedVideoWillAppearForCustomEvent:)]) {
        [self.delegate rewardedVideoWillAppearForCustomEvent:self];
    }
    
    if ([self.delegate respondsToSelector:@selector(rewardedVideoDidAppearForCustomEvent:)]) {
        [self.delegate rewardedVideoDidAppearForCustomEvent:self];
    }
}

@end

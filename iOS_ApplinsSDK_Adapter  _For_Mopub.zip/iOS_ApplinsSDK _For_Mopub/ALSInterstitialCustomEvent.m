//
//  ALSInterstitialCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "ALSInterstitialCustomEvent.h"
#import <ApplinsSDK/ApplinsSDK.h>
#import <ApplinsSDK/ALSADMRAIDView.h>

@interface ALSInterstitialCustomEvent()<ALSAdViewDelegate>

@end

@implementation ALSInterstitialCustomEvent

- (void)requestInterstitialWithCustomEventInfo:(NSDictionary *)info
{
    NSString *slotid = [info objectForKey:@"slotid"];
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK initSDK:slotid];
    
    [alsSDK preloadInterstitialAd:slotid delegate:self isTest:NO];
}


- (void)showInterstitialFromRootViewController:(UIViewController *)rootViewController
{
    Applins *alsSDK = [Applins shareSDK];
    [alsSDK showInterstitialAD];
    
    if ([self.delegate respondsToSelector:@selector(trackImpression)])
    {
        [self.delegate trackImpression];
    }
}

- (void)dealloc
{
    
}

#pragma mark CTAdViewDelegate methods
// Interstitial ad Success
- (void)ALSLoadInterstitialSuccess {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didLoadAd:)])
    {
        [self.delegate interstitialCustomEvent:self didLoadAd:nil];
    }
    
}

//error while request ads.
- (void)ALSAdView:(ALSADMRAIDView*)adView loadADFailedWithError:(NSError*)error {
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didFailToLoadAdWithError:)])
    {
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:error];
    }
}

//jump to safari or internal webview
- (BOOL)ALSAdView:(ALSADMRAIDView*)adView shouldOpenURL:(NSURL*)url {
    if ([self.delegate respondsToSelector:@selector(trackClick)])
    {
        [self.delegate trackClick];
    }
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidReceiveTapEvent:)])
    {
        [self.delegate interstitialCustomEventDidReceiveTapEvent:self];
    }
    return YES;
}


//will leave application
- (void)ALSAdViewWillLeaveApplication:(ALSADMRAIDView*)adView {
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventWillLeaveApplication:)])
    {
        [self.delegate interstitialCustomEventWillLeaveApplication:self];
    }
}

//did click close button
- (void)ALSAdViewCloseButtonPressed:(ALSADMRAIDView*)adView {
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventWillDisappear:)])
    {
        [self.delegate interstitialCustomEventWillDisappear:self];
    }
    
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidDisappear:)])
    {
        [self.delegate interstitialCustomEventDidDisappear:self];
    }
    
}
@end
